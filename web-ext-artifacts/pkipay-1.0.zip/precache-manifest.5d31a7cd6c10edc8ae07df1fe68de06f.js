self.__precacheManifest = [
  {
    "revision": "495229b647900d0fdc10",
    "url": "/static/js/main.ba57b17e.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "f511ec03b8ea15dfc971",
    "url": "/static/js/2.de190f64.chunk.js"
  },
  {
    "revision": "042a58020998f860bb7745a0e7421f75",
    "url": "/index.html"
  }
];