self.__precacheManifest = [
  {
    "revision": "0c05b86f2abdad3ebb59",
    "url": "/static/js/main.71d06491.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "431817184b1b4be12042",
    "url": "/static/js/2.1268b336.chunk.js"
  },
  {
    "revision": "057e302cc9b686b4857f48e1f2fa7c4f",
    "url": "/index.html"
  }
];