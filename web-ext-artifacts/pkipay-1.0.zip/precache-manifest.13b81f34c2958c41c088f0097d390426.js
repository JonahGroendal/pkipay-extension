self.__precacheManifest = [
  {
    "revision": "abbdd834cb52ba554f0b",
    "url": "/static/js/main.d5145f69.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "a0e1df97332b44776f92",
    "url": "/static/js/2.99880149.chunk.js"
  },
  {
    "revision": "61435a82bde24ef0245c1ff9b67f256d",
    "url": "/index.html"
  }
];