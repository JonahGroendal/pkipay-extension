self.__precacheManifest = [
  {
    "revision": "90bba0d1708526c11140",
    "url": "/static/js/main.ca4c0ae4.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "fa376747de40b90b8f06",
    "url": "/static/js/2.09342a15.chunk.js"
  },
  {
    "revision": "5702c7dee9f1536d6f224b50ffd11632",
    "url": "/index.html"
  }
];