self.__precacheManifest = [
  {
    "revision": "b641bb705c73cda85948",
    "url": "/static/js/main.8d229290.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "431817184b1b4be12042",
    "url": "/static/js/2.1268b336.chunk.js"
  },
  {
    "revision": "44deb2760b17a0326b1e2a4bed7d8da3",
    "url": "/index.html"
  }
];