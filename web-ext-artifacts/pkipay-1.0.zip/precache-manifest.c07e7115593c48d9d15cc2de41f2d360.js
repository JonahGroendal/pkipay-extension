self.__precacheManifest = [
  {
    "revision": "754044120ea3a9abbcd1",
    "url": "/static/js/main.f89a6997.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "f679a61c484ec377b99e",
    "url": "/static/js/2.ff882379.chunk.js"
  },
  {
    "revision": "b64e2abdfb0ad8960b4d0eb767a8bea7",
    "url": "/index.html"
  }
];