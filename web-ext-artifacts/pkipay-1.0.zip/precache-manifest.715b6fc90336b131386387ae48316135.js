self.__precacheManifest = [
  {
    "revision": "c97f1138933dd0a351b0",
    "url": "/static/js/main.74ddfdb4.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "f679a61c484ec377b99e",
    "url": "/static/js/2.ff882379.chunk.js"
  },
  {
    "revision": "f213eed2a0fd6504e3ac8cdc16d865b0",
    "url": "/index.html"
  }
];