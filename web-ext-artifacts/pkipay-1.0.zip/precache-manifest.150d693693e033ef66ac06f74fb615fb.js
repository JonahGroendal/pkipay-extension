self.__precacheManifest = [
  {
    "revision": "b474f2c5c2cc14f17cc6",
    "url": "/static/js/main.4cd6acab.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "5ac0b8619c5dd88cf0f2",
    "url": "/static/js/2.f4f472e4.chunk.js"
  },
  {
    "revision": "a987b9bf11c99acf40ded6d137c023dc",
    "url": "/index.html"
  }
];