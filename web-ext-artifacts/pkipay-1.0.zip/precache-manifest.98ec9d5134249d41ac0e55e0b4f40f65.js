self.__precacheManifest = [
  {
    "revision": "ac72944ea0f1a2c3ea45",
    "url": "/static/js/main.e4298f0c.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "15ac740ba627ea3a77f0",
    "url": "/static/js/2.d696ba26.chunk.js"
  },
  {
    "revision": "988ab5601cde63eed845a6ad0791ed3f",
    "url": "/index.html"
  }
];