self.__precacheManifest = [
  {
    "revision": "3923a67bde5eb5a91460",
    "url": "/static/js/main.2e66dad4.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "049eb30d37d9eae22930",
    "url": "/static/js/2.54961e48.chunk.js"
  },
  {
    "revision": "4df0c74b6f5c0824820c16a47f1b3a95",
    "url": "/index.html"
  }
];